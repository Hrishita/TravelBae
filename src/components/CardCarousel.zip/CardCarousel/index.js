import React from "react";
import {
  Box,
  Card,
  CardActionArea,
  CardContent,
  CardMedia,
  Grid,
  Typography,
} from "@material-ui/core";
import Carousel from "react-material-ui-carousel";
import KenyaImg from "../../assets/kenya.jpg";
import SwitzerlandImg from "../../assets/switzerland.jpg";
import IndiaImg from "../../assets/India.jpg";
import ParisImg from "../../assets/paris.jpg";
import NewYorkImg from "../../assets/NewYork.jpg";

const CardCarouselComp = () => {
  const cities = ["Kenya", "Switzerland", "India", "Paris", "New York"];
  const images = [KenyaImg, SwitzerlandImg, IndiaImg, ParisImg, NewYorkImg];
  const displayCards = (item, index) => {
    return (
      <Card>
        <CardActionArea>
          <CardMedia
            component="img"
            height="500"
            image={images[index]}
            alt="green iguana"
          />
          <CardContent>
            <Typography gutterBottom variant="h5" component="div">
              {cities[index]}
            </Typography>
            <Typography variant="body2" color="text.secondary">
              Lorem ipsum dolor sit amet, consectetur adipiscing elit. Mauris
              dapibus sagittis elit, sed varius dolor mattis non. Donec non
              vestibulum leo, quis pellentesque felis. Nullam a magna at mauris
              aliquam porttitor nec ac enim. Nam et ultricies neque.
            </Typography>
          </CardContent>
        </CardActionArea>
      </Card>
    );
  };
  return <>{cities.map((city, index) => displayCards(city, index))}</>;
};
export default CardCarouselComp;
